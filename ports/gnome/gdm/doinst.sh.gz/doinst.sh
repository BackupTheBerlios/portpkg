if [ -x /usr/bin/scrollkeeper-update ]; then
  /usr/bin/scrollkeeper-update -p /var/lib/scrollkeeper 1> /dev/null 2> /dev/null
fi
