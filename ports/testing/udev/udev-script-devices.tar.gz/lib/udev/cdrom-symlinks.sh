#!/bin/sh
if [ -z $udev_root ]; then
	  . /etc/udev/udev.conf
fi

# initiate some vars
cd_num=0
dvd_num=0
cdrw_num=0
dvdrw_num=0
optical_device=$1

if ! ls -l $udev_root | grep -q ^l.*$optical_device ; then
  let `/lib/udev/cdrom_id --export /dev/${optical_device}`
  cd $udev_root

  for i in `/bin/ls cdrom? 2>/dev/null`; do
    cd_num=$(($cd_num + 1))
  done

  if [ "$cd_num" = "0" ]; then
    ln -sf $optical_device cdrom
    ln -sf $optical_device cdrom0
  else
    ln -sf $optical_device cdrom${cd_num}
  fi

  if [ -n "$ID_CDROM_DVD" ]; then 
    for i in `/bin/ls dvd? 2>/dev/null`; do
      dvd_num=$(($dvd_num + 1))
    done
    if [ "$dvd_num" = "0" ]; then
      ln -sf $optical_device dvd 
      ln -sf $optical_device dvd0
    else
      ln -sf $optical_device dvd${dvd_num}
    fi
    if [ -n "$ID_CDROM_DVD_R" ] || [ -n "$ID_CDROM_DVD_RAM" ]; then
        for i in `/bin/ls dvdrw? 2>/dev/null`; do
          dvdrw_num=$(($dvdrw_num + 1))
        done
    	if [ "$dvdrw_num" = "0" ]; then
    	  ln -sf $optical_device dvdrw 
    	  ln -sf $optical_device dvdrw0
    	else
    	  ln -sf $optical_device dvdrw${dvdrw_num}
    	fi
    fi
  fi

  if [ -n "$ID_CDROM_CD_RW" ]; then
    for i in `/bin/ls cdrw? 2>/dev/null`; do
      cdrw_num=$(($cdrw_num + 1))
    done
    if [ "$cdrw_num" = "0" ]; then
      ln -sf $optical_device cdrw 
      ln -sf $optical_device cdrw0
    else
      ln -sf $optical_device cdrw${cdrw_num}
    fi
  fi
fi
