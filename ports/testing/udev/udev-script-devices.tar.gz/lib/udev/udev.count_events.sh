#!/bin/sh -e
#
# Wait for all running udev processes to finish

while true; do
    running=$(cat /proc/*/status 2> /dev/null | grep -c -E '^Name:.udevd?$')
    if [ $running -gt 1 ]; then
	echo "udevd: $running processes running" >&2
	sleep 1 
    else
	rm /var/lock/subsys/coldplug
	exit 0
    fi
done
