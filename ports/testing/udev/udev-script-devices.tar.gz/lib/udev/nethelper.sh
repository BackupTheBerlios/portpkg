#!/bin/sh
NAME="$1"
COMMAND="$2"

case $COMMAND in
	'start')
		KRN_NAME=`echo $NAME | sed -ne 's#\(\w*\)[0-9].*#\1#p'`
		if [ "$KRN_NAME" != "" ]; then
			case $KRN_NAME in
				eth|wlan)
					ADDRESS=`cat /sys/class/net/${NAME}/address`
					if ! grep "$ADDRESS" /etc/udev/rules.d/* &>/dev/null ; then
						echo "KERNEL==\"${KRN_NAME}?\", SYSFS{address}==\"$ADDRESS\", NAME=\"$NAME\"" >> /etc/udev/rules.d/network-devices.rules
					fi
					/etc/rc.d/rc.inet1 ${NAME}_start
					if `ifconfig ${NAME} | grep "inet addr" &>/dev/null` ; then
						exit 0
					else
						exit 1
					fi
					;;
				*)
					exit 0
					;;
			esac
		fi
		;;
	'stop')
		/etc/rc.d/rc.inet1 ${NAME}_stop
		;;
	*)
		echo "usage $0 interface start|stop|restart"
		exit 1
		;;
esac
