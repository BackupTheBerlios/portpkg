#!/bin/sh
NAME="$1"
COMMAND="$2"

case $COMMAND in
	'start')
		case $NAME in
			ppp*|ippp*|isdn*|plip*|lo*|irda*|dummy*|tun*|tap*)
				exit 0
				;;
			*)
				ADDRESS=`cat /sys/class/net/${NAME}/address`
				if ! grep "$ADDRESS" /etc/udev/rules.d/* &>/dev/null ; then
					KRN_NAME=`echo $NAME | sed -ne 's#\(\w*\)[0-9].*#\1#p'`
					echo "KERNEL==\"${KRN_NAME}?\", SYSFS{address}==\"$ADDRESS\", NAME=\"$NAME\"" >> /etc/udev/rules.d/network-devices.rules
				fi
				if [ -e /var/lock/subsys/coldplug ] ; then
					exit 1
				elif [ -x /etc/rc.d/rc.inet1 ]; then
				     if ! /sbin/ifconfig | /bin/grep -q "^${NAME} "; then
					/etc/rc.d/rc.inet1 ${NAME}_start
					exit 0
				     fi
				fi
				;;
		esac
		;;
	'stop')
		case $NAME in
			ppp*|ippp*|isdn*|plip*|lo*|irda*|dummy*|tun*|tap*)
				exit 0
				;;
			*)
				if [ -x /etc/rc.d/rc.inet1 ]; then
				     if /sbin/ifconfig | /bin/grep -q "^${NAME} "; then
					/etc/rc.d/rc.inet1 ${NAME}_stop
				     fi
				fi
				# Does dhcpcd appear to still be running on the interface?  If so, try to stop it.
				if [ -r /etc/dhcpc/dhcpcd-$NAME.pid -o -r /var/run/dhcpcd-$NAME.pid ]; then
				  /sbin/dhcpcd -k -d $NAME
				  # Force garbage removal, if needed:
				  if [ -r /etc/dhcpc/dhcpcd-$NAME.pid ]; then
				     /bin/rm -f /etc/dhcpc/dhcpcd-$NAME.pid
				  elif [ -r /var/run/dhcpcd-$NAME.pid ]; then
				     /bin/rm -f /var/run/dhcpcd-$NAME.pid
				  fi
				fi
			    	# If the interface is now down, exit with a status of 0:
			    	if /sbin/ifconfig | /bin/grep -q "^${NAME} " ; then
			    	  exit 0
			    	fi
				;;
		esac
		;;
	*)
		echo "usage $0 interface start|stop|restart"
		exit 1
		;;
esac
exit 0
